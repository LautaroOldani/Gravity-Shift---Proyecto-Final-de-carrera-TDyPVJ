extends StaticBody2D

@export var tiempo_para_caer: float = 0.8   
@export var tiempo_para_volver: float = 2.0 

@onready var collision_piso = $CollisionShape2D
@onready var sprite = $ColorRect
@onready var area_deteccion = $Area2D
@onready var timer_caida = $TiempoCaida     
@onready var timer_respawn = $TiempoRespawn 

var activada: bool = false

func _ready():
	timer_caida.wait_time = tiempo_para_caer
	timer_respawn.wait_time = tiempo_para_volver
	
	
	if area_deteccion:
		area_deteccion.body_entered.connect(_on_body_entered)
		
	timer_caida.timeout.connect(_desaparecer)
	timer_respawn.timeout.connect(_reaparecer)

func _on_body_entered(body):
	if not activada and (body.is_in_group("jugador") or body.is_in_group("caja")):
		activada = true
		timer_caida.start()

func _desaparecer():
	
	if sprite:
		sprite.visible = false
	collision_piso.set_deferred("disabled", true) 
	
	if area_deteccion:
		area_deteccion.monitoring = false             
		
	timer_respawn.start()

func _reaparecer():
	
	if sprite:
		sprite.visible = true
	collision_piso.set_deferred("disabled", false) 
	
	if area_deteccion:
		area_deteccion.monitoring = true              
		
	activada = false
