extends CanvasLayer

@export var carga_1: Control
@export var carga_2: Control
@export var carga_3: Control

func actualizar_cargas(cargas_actuales: int):
	var iconos_cargas = [carga_1, carga_2, carga_3]
	
	for i in range(iconos_cargas.size()):
		if iconos_cargas[i] != null:
			if i < cargas_actuales:
				iconos_cargas[i].visible = true
			else:
				iconos_cargas[i].visible = false
		else:
			print("¡Falta arrastrar la carga ", i + 1, " en el Inspector del HUD!")
