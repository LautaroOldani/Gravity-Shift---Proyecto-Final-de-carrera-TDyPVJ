extends StaticBody2D

func abrir() -> void:

	queue_free()
