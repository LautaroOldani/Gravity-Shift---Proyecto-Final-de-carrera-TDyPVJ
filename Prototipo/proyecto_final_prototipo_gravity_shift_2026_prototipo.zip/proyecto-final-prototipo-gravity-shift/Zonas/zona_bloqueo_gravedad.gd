extends Area2D


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("jugador") or body is CharacterBody2D:
		
		if "gravedad_bloqueada_por_zona" in body:
			body.gravedad_bloqueada_por_zona = true
		
		
		if body.has_method("aplicar_nueva_gravedad"):
			body.aplicar_nueva_gravedad(Vector2.DOWN)


func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("jugador") or body is CharacterBody2D:
		
		if "gravedad_bloqueada_por_zona" in body:
			body.gravedad_bloqueada_por_zona = false
