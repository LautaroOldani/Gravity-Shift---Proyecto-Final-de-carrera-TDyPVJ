extends CharacterBody2D

const SPEED = 100.0
const JUMP_VELOCITY = 320.0 
const VELOCIDAD_MAXIMA_CAIDA: float = 150.0 

@export var gravedad_libre_habilitada: bool = false

@export var max_cargas: int = 3
var cargas_actuales: int = 3
@export var hud: CanvasLayer

var modo_vertical_activo: bool = false
var modo_horizontal_activo: bool = false

var ultimo_checkpoint_pos: Vector2

var gravity_dir: Vector2 = Vector2.DOWN
var gravity_magnitude: float = ProjectSettings.get_setting("physics/2d/default_gravity")

var gravedad_bloqueada_por_zona: bool = false
var bloqueo_horizontal_por_zona: bool = false
var zona_gravedad_actual: Area2D = null

var tecla_w_presionada_antes: bool = false
var tecla_s_presionada_antes: bool = false
var tecla_a_presionada_antes: bool = false
var tecla_d_presionada_antes: bool = false


func _ready() -> void:
	ultimo_checkpoint_pos = global_position
	get_tree().call_group("caja", "actualizar_gravedad", gravity_dir, gravity_magnitude)
	
	if hud:
		hud.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_G:
			if zona_gravedad_actual != null and not zona_gravedad_actual.zona_activa:
				return
				
			modo_vertical_activo = !modo_vertical_activo
			
			if not modo_vertical_activo:
				aplicar_nueva_gravedad(Vector2.DOWN)
				
		elif event.keycode == KEY_H:
			if bloqueo_horizontal_por_zona:
				return
				
			if zona_gravedad_actual != null and not zona_gravedad_actual.zona_activa:
				return
				
			modo_horizontal_activo = !modo_horizontal_activo
			
			if not modo_horizontal_activo:
				aplicar_nueva_gravedad(Vector2.DOWN)


func _physics_process(delta: float) -> void:
	if not is_inside_tree() or get_world_2d() == null:
		return

	if hud:
		hud.visible = (zona_gravedad_actual != null)

	var w_actual = Input.is_key_pressed(KEY_W)
	var s_actual = Input.is_key_pressed(KEY_S)
	var a_actual = Input.is_key_pressed(KEY_A)
	var d_actual = Input.is_key_pressed(KEY_D)

	if (modo_vertical_activo or gravedad_libre_habilitada) and not gravedad_bloqueada_por_zona:
		if w_actual and not tecla_w_presionada_antes:
			if gravity_dir != Vector2.UP:
				if validar_y_gastar_carga():
					aplicar_nueva_gravedad(Vector2.UP)
		elif s_actual and not tecla_s_presionada_antes:
			if gravity_dir != Vector2.DOWN:
				if validar_y_gastar_carga():
					aplicar_nueva_gravedad(Vector2.DOWN)

	if (modo_horizontal_activo or gravedad_libre_habilitada) and not gravedad_bloqueada_por_zona and not bloqueo_horizontal_por_zona:
		if a_actual and not tecla_a_presionada_antes:
			if gravity_dir != Vector2.LEFT:
				if validar_y_gastar_carga():
					aplicar_nueva_gravedad(Vector2.LEFT)
		elif d_actual and not tecla_d_presionada_antes:
			if gravity_dir != Vector2.RIGHT:
				if validar_y_gastar_carga():
					aplicar_nueva_gravedad(Vector2.RIGHT)

	tecla_w_presionada_antes = w_actual
	tecla_s_presionada_antes = s_actual
	tecla_a_presionada_antes = a_actual
	tecla_d_presionada_antes = d_actual

	velocity += gravity_dir * gravity_magnitude * delta

	var velocidad_caida: float = velocity.dot(gravity_dir)
	if velocidad_caida > VELOCIDAD_MAXIMA_CAIDA:
		velocity -= gravity_dir * (velocidad_caida - VELOCIDAD_MAXIMA_CAIDA)

	up_direction = -gravity_dir

	if gravity_dir.y != 0:
		var direction := Input.get_axis("ui_left", "ui_right")
		if direction != 0:
			velocity.x = direction * SPEED
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)

		if (Input.is_action_just_pressed("ui_accept") or Input.is_action_just_pressed("ui_up")) and is_on_floor():
			velocity += up_direction * JUMP_VELOCITY

	else:
		var direction := Input.get_axis("ui_up", "ui_down")
		if direction != 0:
			velocity.y = direction * SPEED
		else:
			velocity.y = move_toward(velocity.y, 0, SPEED)

		if Input.is_action_just_pressed("ui_accept") and is_on_floor():
			velocity += up_direction * JUMP_VELOCITY

	move_and_slide()

	for i in get_slide_collision_count():
		var colision := get_slide_collision(i)
		var collider := colision.get_collider()
		
		if collider and collider.is_in_group("enemigo"):
			morir()
			break
		
		if collider is RigidBody2D:
			var direccion_empuje := -colision.get_normal()
			collider.linear_velocity = direccion_empuje * SPEED * 0.6


func validar_y_gastar_carga() -> bool:
	if zona_gravedad_actual != null:
		if zona_gravedad_actual.has_method("intentar_cambiar_gravedad") and not zona_gravedad_actual.intentar_cambiar_gravedad():
			return false
		
		if cargas_actuales > 0:
			cargas_actuales -= 1
			if hud:
				hud.actualizar_cargas(cargas_actuales)
			return true
		return false
	else:
		return intentar_cambio_gravedad_restringido()


func aplicar_nueva_gravedad(nueva_dir: Vector2) -> void:
	if gravity_dir != nueva_dir.normalized():
		gravity_dir = nueva_dir.normalized()
		
		velocity = Vector2.ZERO
		
		match gravity_dir:
			Vector2.DOWN:
				rotation = 0.0
			Vector2.UP:
				rotation = PI
			Vector2.LEFT:
				rotation = PI / 2
			Vector2.RIGHT:
				rotation = -PI / 2

		get_tree().call_group("caja", "actualizar_gravedad", gravity_dir, gravity_magnitude)


func intentar_cambio_gravedad_restringido() -> bool:
	if zona_gravedad_actual != null:
		return zona_gravedad_actual.intentar_cambiar_gravedad()
	return true


func actualizar_checkpoint(nueva_pos: Vector2) -> void:
	ultimo_checkpoint_pos = nueva_pos


func morir() -> void:
	set_physics_process(false)
	modo_vertical_activo = false
	modo_horizontal_activo = false
	
	aplicar_nueva_gravedad(Vector2.DOWN)
	velocity = Vector2.ZERO

	global_position = ultimo_checkpoint_pos
	
	cargas_actuales = max_cargas
	if hud:
		hud.actualizar_cargas(cargas_actuales)
	
	if zona_gravedad_actual != null and zona_gravedad_actual.has_method("resetear_intentos"):
		zona_gravedad_actual.resetear_intentos()
	
	get_tree().call_group("caja", "resetear_caja")
	
	set_physics_process.call_deferred(true)


func reaparecer() -> void:
	morir()
