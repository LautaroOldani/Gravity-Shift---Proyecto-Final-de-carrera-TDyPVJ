extends Area2D


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		
		body.aplicar_nueva_gravedad(Vector2.DOWN)
		body.gravedad_bloqueada_por_zona = true


func _on_body_exited(body: Node2D) -> void:
	if body is CharacterBody2D:
		
		body.gravedad_bloqueada_por_zona = false
