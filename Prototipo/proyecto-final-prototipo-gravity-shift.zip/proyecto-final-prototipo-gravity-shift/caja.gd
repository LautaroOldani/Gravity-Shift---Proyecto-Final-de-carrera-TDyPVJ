extends RigidBody2D

var posicion_inicial: Vector2


func _ready() -> void:
	posicion_inicial = global_position



func resetear_caja() -> void:
	linear_velocity = Vector2.ZERO
	angular_velocity = 0.0
	global_position = posicion_inicial
