extends Area2D

@export var id_boton: int = 1
@export var puerta: Node2D

var ya_presionado: bool = false


func _on_body_entered(body: Node2D) -> void:
	
	if not ya_presionado and (body.is_in_group("jugador") or body.is_in_group("caja")):
		ya_presionado = true
		
		
		
		if puerta and puerta.has_method("boton_presionado"):
			puerta.boton_presionado(id_boton)



func reiniciar_boton() -> void:
	ya_presionado = false
	modulate = Color.WHITE
