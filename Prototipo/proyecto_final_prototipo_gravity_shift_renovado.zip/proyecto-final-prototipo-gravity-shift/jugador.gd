extends CharacterBody2D

const SPEED = 100.0
const JUMP_VELOCITY = 320.0 
const VELOCIDAD_MAXIMA_CAIDA: float = 150.0 

@export var gravedad_libre_habilitada: bool = false

var modo_vertical_activo: bool = false
var modo_horizontal_activo: bool = false

# Cambiamos posicion_inicial por ultimo_checkpoint_pos
var ultimo_checkpoint_pos: Vector2

var gravity_dir: Vector2 = Vector2.DOWN
var gravity_magnitude: float = ProjectSettings.get_setting("physics/2d/default_gravity")

var gravedad_bloqueada_por_zona: bool = false


func _ready() -> void:
	# Guardamos la posición del inicio como el primer checkpoint por defecto
	ultimo_checkpoint_pos = global_position
	get_tree().call_group("caja", "actualizar_gravedad", gravity_dir, gravity_magnitude)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_G:
			modo_vertical_activo = !modo_vertical_activo
			
			if not modo_vertical_activo:
				aplicar_nueva_gravedad(Vector2.DOWN)
				
		elif event.keycode == KEY_H:
			modo_horizontal_activo = !modo_horizontal_activo
			
			if not modo_horizontal_activo:
				aplicar_nueva_gravedad(Vector2.DOWN)


func _physics_process(delta: float) -> void:
	
	if (modo_vertical_activo or gravedad_libre_habilitada) and not gravedad_bloqueada_por_zona:
		if Input.is_key_pressed(KEY_W):
			aplicar_nueva_gravedad(Vector2.UP)
		elif Input.is_key_pressed(KEY_S):
			aplicar_nueva_gravedad(Vector2.DOWN)

	if (modo_horizontal_activo or gravedad_libre_habilitada) and not gravedad_bloqueada_por_zona:
		if Input.is_key_pressed(KEY_A):
			aplicar_nueva_gravedad(Vector2.LEFT)
		elif Input.is_key_pressed(KEY_D):
			aplicar_nueva_gravedad(Vector2.RIGHT)

	
	velocity += gravity_dir * gravity_magnitude * delta


	var velocidad_caida: float = velocity.dot(gravity_dir)
	if velocidad_caida > VELOCIDAD_MAXIMA_CAIDA:
		
		velocity -= gravity_dir * (velocidad_caida - VELOCIDAD_MAXIMA_CAIDA)

	up_direction = -gravity_dir

	
	if gravity_dir.y != 0:
		var direction := Input.get_axis("ui_left", "ui_right")
		if direction != 0:
			velocity.x = direction * SPEED
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)

		if (Input.is_action_just_pressed("ui_accept") or Input.is_action_just_pressed("ui_up")) and is_on_floor():
			velocity += up_direction * JUMP_VELOCITY

	else:
		var direction := Input.get_axis("ui_up", "ui_down")
		if direction != 0:
			velocity.y = direction * SPEED
		else:
			velocity.y = move_toward(velocity.y, 0, SPEED)

		if Input.is_action_just_pressed("ui_accept") and is_on_floor():
			velocity += up_direction * JUMP_VELOCITY

	move_and_slide()


	for i in get_slide_collision_count():
		var colision := get_slide_collision(i)
		var collider := colision.get_collider()
		
		if collider and collider.is_in_group("enemigo"):
			morir()
			break
		
		if collider is RigidBody2D:
			var direccion_empuje := -colision.get_normal()
			collider.linear_velocity = direccion_empuje * SPEED * 0.6


func aplicar_nueva_gravedad(nueva_dir: Vector2) -> void:
	if gravity_dir != nueva_dir.normalized():
		gravity_dir = nueva_dir.normalized()
		
		velocity = Vector2.ZERO
		
		match gravity_dir:
			Vector2.DOWN:
				rotation = 0.0
			Vector2.UP:
				rotation = PI
			Vector2.LEFT:
				rotation = PI / 2
			Vector2.RIGHT:
				rotation = -PI / 2

		get_tree().call_group("caja", "actualizar_gravedad", gravity_dir, gravity_magnitude)



func actualizar_checkpoint(nueva_pos: Vector2) -> void:
	ultimo_checkpoint_pos = nueva_pos


func morir() -> void:
	modo_vertical_activo = false
	modo_horizontal_activo = false
	
	aplicar_nueva_gravedad(Vector2.DOWN)
	velocity = Vector2.ZERO

	set_deferred("global_position", ultimo_checkpoint_pos)
	get_tree().call_group("caja", "resetear_caja")


func reaparecer() -> void:
	morir()
