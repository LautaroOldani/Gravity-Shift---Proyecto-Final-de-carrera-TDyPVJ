extends RigidBody2D

const VELOCIDAD_MAXIMA_CAIDA: float = 150.0

var gravity_dir: Vector2 = Vector2.DOWN
var gravity_magnitude: float = ProjectSettings.get_setting("physics/2d/default_gravity")


var bloqueada: bool = false


func _ready() -> void:
	gravity_scale = 0.0


func _physics_process(delta: float) -> void:
	
	linear_velocity += gravity_dir * gravity_magnitude * delta

	
	var velocidad_caida: float = linear_velocity.dot(gravity_dir)
	if velocidad_caida > VELOCIDAD_MAXIMA_CAIDA:
		linear_velocity -= gravity_dir * (velocidad_caida - VELOCIDAD_MAXIMA_CAIDA)


func actualizar_gravedad(nueva_dir: Vector2, magnitud: float) -> void:
	
	if bloqueada:
		return
		
	print("¡GRAVEDAD RECIBIDA EN CAJA!: ", nueva_dir)
	gravity_dir = nueva_dir.normalized()
	gravity_magnitude = magnitud
	
	
	sleeping = false
	linear_velocity = Vector2.ZERO


func fijar_gravedad_normal() -> void:
	bloqueada = true
	
	
	gravity_dir = Vector2.DOWN
	
	
	linear_velocity = Vector2(0, max(0.0, linear_velocity.y))
	angular_velocity = 0.0
	
	
	rotation = 0.0
	sleeping = false
	
	print("Caja desvinculada del jugador: cayendo hacia abajo con gravedad normal.")


func resetear_caja() -> void:
	linear_velocity = Vector2.ZERO
	angular_velocity = 0.0
	sleeping = false
	bloqueada = false
