extends StaticBody2D

# Al 
@export var interruptores_necesarios: int = 2

var interruptores_activados: int = 0


func abrir() -> void:
	interruptores_activados += 1
	print("Interruptores activados: ", interruptores_activados, "/", interruptores_necesarios)
	
	
	if interruptores_activados >= interruptores_necesarios:
		$CollisionShape2D.set_deferred("disabled", true)
		visible = false
