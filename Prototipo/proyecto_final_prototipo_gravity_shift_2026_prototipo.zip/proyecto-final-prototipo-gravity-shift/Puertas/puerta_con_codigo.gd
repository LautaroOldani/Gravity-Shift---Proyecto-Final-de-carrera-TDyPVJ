extends StaticBody2D


@export var secuencia_correcta: Array[int] = [1, 2, 3, 4]
@export var lista_botones: Array[Area2D] 

var secuencia_ingresada: Array[int] = []

func boton_presionado(id_boton: int) -> void:
	secuencia_ingresada.append(id_boton)
	
	var indice_actual = secuencia_ingresada.size() - 1
	
	
	if secuencia_ingresada[indice_actual] != secuencia_correcta[indice_actual]:
		print("¡Error! Secuencia incorrecta.")
		_resetear_puzle()
		return
	
	
	if secuencia_ingresada.size() == secuencia_correcta.size():
		print("¡Puzle resuelto! Abriendo puerta a la torre...")
		_abrir_puerta()

func _resetear_puzle() -> void:
	secuencia_ingresada.clear()
	for boton in lista_botones:
		if boton and boton.has_method("reiniciar_boton"):
			boton.reiniciar_boton()

func _abrir_puerta() -> void:
	visible = false
	$CollisionShape2D.set_deferred("disabled", true)
