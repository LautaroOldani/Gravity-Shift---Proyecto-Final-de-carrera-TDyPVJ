extends Area2D

var activado: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if not activado and body.has_method("actualizar_checkpoint"):
		body.actualizar_checkpoint(global_position)
		activado = true
