extends CharacterBody2D

@export var velocidad: float = 80.0
var direccion: int = 1

@onready var ray_pared = $RayPared
@onready var sprite = $Sprite2D

func _physics_process(_delta: float) -> void:
	velocity.x = velocidad * direccion
	velocity.y = 0.0
	
	move_and_slide()
	
	if ray_pared.is_colliding():
		cambiar_direccion()

func cambiar_direccion() -> void:
	direccion *= -1
	ray_pared.target_position.x *= -1
	ray_pared.position.x *= -1
	
	if sprite:
		sprite.flip_h = (direccion == -1)


func _on_dano_area_body_entered(body: Node2D) -> void:
	if body.has_method("morir"):
		body.morir()
