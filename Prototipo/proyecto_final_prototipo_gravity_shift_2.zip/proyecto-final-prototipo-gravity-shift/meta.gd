extends Area2D


@export_file("*.tscn") var siguiente_nivel: String

@onready var cartel_victoria: Label = $CanvasLayer/Label

var juego_ganado: bool = false

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	
	if cartel_victoria:
		cartel_victoria.visible = false

func _process(_delta: float) -> void:

	if juego_ganado and Input.is_key_pressed(KEY_R):
		get_tree().reload_current_scene()

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D:
		juego_ganado = true
		if cartel_victoria:
			cartel_victoria.visible = true
		
		
		if siguiente_nivel != "":
			get_tree().call_deferred("change_scene_to_file", siguiente_nivel)
