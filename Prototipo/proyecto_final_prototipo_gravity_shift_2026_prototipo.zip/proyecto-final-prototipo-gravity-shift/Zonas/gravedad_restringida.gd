extends Area2D

@export var max_cambios: int = 3
var cambios_actuales: int = 0
var zona_activa: bool = true

func _ready():
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body):
	if body.is_in_group("jugador"):
		cambios_actuales = 0 
		body.zona_gravedad_actual = self
		print("Entraste a la zona. Cambios usados: 0 / ", max_cambios)

func _on_body_exited(body):
	if body.is_in_group("jugador"):
		if body.zona_gravedad_actual == self:
			body.zona_gravedad_actual = null
		print("Saliste de la zona.")

func intentar_cambiar_gravedad() -> bool:
	if not zona_activa:
		return false

	if cambios_actuales < max_cambios:
		cambios_actuales += 1
		print("¡Cambio exitoso! Usados: ", cambios_actuales, " / ", max_cambios)
		return true 
	else:
		print("¡Te pasaste de los 3 cambios! Volviendo al checkpoint...")
		zona_activa = false
		
		var jugador = get_tree().get_first_node_in_group("jugador")
		if jugador and jugador.has_method("morir"):
			jugador.call_deferred("morir")
		else:
			get_tree().call_deferred("reload_current_scene")
			
		get_tree().create_timer(1.0).timeout.connect(func(): 
			cambios_actuales = 0
			zona_activa = true
		)
		return false


func resetear_intentos() -> void:
	cambios_actuales = 0
	zona_activa = true
	print("Intentos reseteados por muerte. Cambios usados: 0 / ", max_cambios)
