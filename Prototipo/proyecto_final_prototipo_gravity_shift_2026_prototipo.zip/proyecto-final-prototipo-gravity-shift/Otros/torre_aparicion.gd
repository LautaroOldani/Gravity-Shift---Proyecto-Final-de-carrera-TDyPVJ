extends StaticBody2D

@onready var colision: CollisionShape2D = $CollisionShape2D


func _ready() -> void:
	desactivar_pilar()


func activar_pilar() -> void:
	visible = true
	if colision:
		colision.set_deferred("disabled", false)


func desactivar_pilar() -> void:
	visible = false
	if colision:
		colision.set_deferred("disabled", true)
