extends AnimatableBody2D

# 
@export var destino: Vector2 = Vector2(120, 0) 
@export var duracion: float = 2.0               

func _ready() -> void:
	iniciar_movimiento()

func iniciar_movimiento() -> void:
	var pos_inicial = position
	var pos_final = position + destino
	
	var tween = create_tween().set_loops().set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "position", pos_final, duracion)
	tween.tween_property(self, "position", pos_inicial, duracion)
