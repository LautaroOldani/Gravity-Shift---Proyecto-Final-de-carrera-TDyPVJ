extends Area2D

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("jugador"):
		body.bloqueo_horizontal_por_zona = true
		if body.modo_horizontal_activo:
			body.modo_horizontal_activo = false
			if body.gravity_dir.x != 0:
				body.aplicar_nueva_gravedad(Vector2.DOWN)


func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("jugador"):
		body.bloqueo_horizontal_por_zona = false
