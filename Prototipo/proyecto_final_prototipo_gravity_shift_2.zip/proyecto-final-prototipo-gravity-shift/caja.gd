extends RigidBody2D

var posicion_inicial: Vector2


func _ready() -> void:
	posicion_inicial = global_position
	
	
	gravity_scale = 1.0
	
	
	linear_damp = 12
	angular_damp = 0.0


func resetear_caja() -> void:
	linear_velocity = Vector2.ZERO
	angular_velocity = 0.0
	global_position = posicion_inicial
