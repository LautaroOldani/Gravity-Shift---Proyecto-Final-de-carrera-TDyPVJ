extends StaticBody2D


@export var botones_necesarios: int = 1
var botones_presionados: int = 0

func registrar_boton() -> void:
	botones_presionados += 1
	print("Botones activados: ", botones_presionados, "/", botones_necesarios)
	
	if botones_presionados >= botones_necesarios:
		print("¡Condición cumplida! Abriendo puerta...")
		call_deferred("queue_free")


func abrir() -> void:
	registrar_boton()
