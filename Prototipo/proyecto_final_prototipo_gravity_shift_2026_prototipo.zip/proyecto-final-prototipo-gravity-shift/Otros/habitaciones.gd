extends Node2D

@export var camara: Camera2D
@export var duracion_transicion: float = 0.4


func _ready() -> void:
	for hijo in get_children():
		if hijo is Area2D:
			hijo.body_entered.connect(_on_habitacion_entered.bind(hijo))


func _on_habitacion_entered(body: Node2D, habitacion: Area2D) -> void:
	if body.is_in_group("jugador"):
		enfocar_habitacion(habitacion)


func enfocar_habitacion(habitacion: Area2D) -> void:
	if not camara:
		return

	var shape_node = habitacion.get_node_or_null("CollisionShape2D")
	if not shape_node or not (shape_node.shape is RectangleShape2D):
		return

	var rect_shape: RectangleShape2D = shape_node.shape
	
	print("--- DATOS DE HABITACION ---")
	print("Posicion Area2D: ", habitacion.global_position)
	print("Posicion CollisionShape2D: ", shape_node.global_position)
	print("Tamano del Shape: ", rect_shape.size)
	print("Escala del Shape: ", shape_node.global_scale)

	var tamano_real: Vector2 = rect_shape.size * shape_node.global_scale
	var pos_centro: Vector2 = shape_node.global_position

	var tamano_pantalla: Vector2 = get_viewport_rect().size
	var zoom_x: float = tamano_pantalla.x / tamano_real.x
	var zoom_y: float = tamano_pantalla.y / tamano_real.y
	var escala_zoom: float = min(zoom_x, zoom_y)

	print("Posicion Centro Calculada: ", pos_centro)
	print("Zoom Calculado: ", escala_zoom)

	var tween := create_tween().set_parallel(true).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(camara, "global_position", pos_centro, duracion_transicion)
	tween.tween_property(camara, "zoom", Vector2(escala_zoom, escala_zoom), duracion_transicion)
