extends Area2D

@export var pilar: Node2D 

var cuerpos_encima: int = 0


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("jugador") or body.is_in_group("caja"):
		cuerpos_encima += 1
		
		
		if cuerpos_encima == 1 and pilar and pilar.has_method("activar_pilar"):
			pilar.activar_pilar()


func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("jugador") or body.is_in_group("caja"):
		cuerpos_encima -= 1
		
		
		if cuerpos_encima <= 0:
			cuerpos_encima = 0
			if pilar and pilar.has_method("desactivar_pilar"):
				pilar.desactivar_pilar()
