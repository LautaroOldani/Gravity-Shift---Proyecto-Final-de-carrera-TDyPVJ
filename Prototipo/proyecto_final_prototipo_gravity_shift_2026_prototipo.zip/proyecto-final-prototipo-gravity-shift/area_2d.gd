extends Area2D

@export var puerta_a_abrir: StaticBody2D

var ya_activado: bool = false


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node2D) -> void:
	if not ya_activado and (body is CharacterBody2D or body is RigidBody2D):
		ya_activado = true
		
		
		if body.has_method("fijar_gravedad_normal"):
			body.fijar_gravedad_normal()
		

		if puerta_a_abrir and puerta_a_abrir.has_method("abrir"):
			puerta_a_abrir.abrir()
